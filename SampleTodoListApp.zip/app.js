var sampleTodoApp = angular.module('SampleTodoApp', ['firebase']);
//var sampleTodoApp = angular.module('SampleTodoApp', ['firebase', 'angular.filter']);